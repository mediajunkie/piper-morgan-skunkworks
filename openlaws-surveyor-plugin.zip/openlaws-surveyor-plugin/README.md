# OpenLaws Surveyor Plugin (v0.1 scaffold)

Proof-of-concept plugin packaging for the OpenLaws Surveyor wrapper. Built as a single-install alternative to the two-registration model in `docs/working/openlaws-surveyor-install-guide-v0.md`.

**Status:** scaffold only. Not yet uploaded / tested in Claude Desktop's Cowork plugin UI. xian's empirical test pass on this scaffold (alongside the v0.1 stub install) determines whether the upload format works.

## What's in this directory

```
openlaws-surveyor-plugin/
├── .claude-plugin/
│   └── plugin.json           # plugin manifest
├── skills/
│   └── surveyor/
│       └── SKILL.md          # Surveyor wrapper behavior
├── .mcp.json                 # bundled MCP server config
├── servers/
│   └── openlaws-mcp-bet/     # symlink → experiments/openlaws-mcp-bet
└── README.md                 # this file
```

The `servers/openlaws-mcp-bet/` is currently a symlink to `experiments/openlaws-mcp-bet/` for development convenience. For real distribution, the symlink would be replaced with a copy (or, longer-term, a published Python package the plugin installs from PyPI).

## Prerequisites

- Claude Desktop installed (macOS).
- `uv` available on the user's PATH (`brew install uv` or per [astral.sh/uv](https://docs.astral.sh/uv/)).
- `OPENLAWS_API_KEY` set in the user's environment before enabling the plugin.

## Trying it

**Path 1 — Sideload via Cowork UI (target):**

1. Zip this directory: `cd experiments && zip -r openlaws-surveyor-plugin.zip openlaws-surveyor-plugin/`
2. Open Claude Desktop, switch to the **Cowork** tab.
3. **Customize → Browse plugins → Upload custom plugin** (exact UI label TBD; xian to verify).
4. Upload the zip.
5. Enable the plugin.
6. Test the hero query: *"Where do I find Texas workers' compensation regulations?"*

**Path 2 — Local-dev via Claude Code (lower-friction first try):**

1. Set `OPENLAWS_API_KEY` in your shell.
2. Run: `claude --plugin-dir ./experiments/openlaws-surveyor-plugin`
3. In the Claude Code session: `/openlaws-surveyor:surveyor Where do I find Texas workers' compensation regulations?`
4. Validate the output surfaces 28 TAC Part 2.

## Open questions to resolve via test

These are documented in `workdesk/bet-1-workers-comp/plugin-packaging-spike-2026-04-30.md` § Open questions:

1. What upload artifact format does Cowork accept (folder, zip, both)?
2. What does Cowork do when the plugin's MCP server fails to start (missing `uv`, bad token, network)?
3. How does Cowork's UI surface the namespaced skill (`openlaws-surveyor:surveyor` vs. just `surveyor`)?
4. Does the `${CLAUDE_PLUGIN_ROOT}` variable resolve correctly through Cowork's plugin install path?

## Relationship to the v0.1 stub

The v0.1 stub (Path A, currently the canonical install path) lives in two separate places:
- Skill at `.claude/skills/openlaws-surveyor/SKILL.md`
- MCP server at `experiments/openlaws-mcp-bet/`

This plugin scaffold (Path C, deferred) wraps both into one. The Skill content is **byte-identical** to the v0.1 stub Skill — it's literally a copy. So everything we learn from the Path A demo Friday applies directly when we move to Path C; the wrapper behavior is the same artifact, just packaged differently.

## When this becomes the canonical install

After v0.1 stub validates Friday + iterations land. See the spike memo for the full upgrade path.
